package consts

const (
	// Used to store auth arguments
	REGION_EN = uint8(1)
	REGION_JP = uint8(2)
	REGION_KR = uint8(3)
	REGION_CN = uint8(4)
	REGION_TW = uint8(5)
)
